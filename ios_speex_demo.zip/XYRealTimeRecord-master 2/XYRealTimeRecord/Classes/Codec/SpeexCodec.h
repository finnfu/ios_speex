//
//  SpeexCodec.h
//  OggSpeex
//
//  Created by Jiang Chuncheng on 11/26/12.
//  Copyright (c) 2012 Sense Force. All rights reserved.
//


#import <Foundation/Foundation.h>
#import "SpeexAllHeaders.h"

@interface SpeexCodec : NSObject {
    int codecOpenedTimes;
    int encodeFrameSize;
    int decodeFrameSize;
    SpeexBits encodeSpeexBits;
    SpeexBits decodeSpeexBits;
    void *encodeState;
    void *decodeState;
}


//初始化
- (void)open:(int)quality;

//压缩
- (NSData *)encode:(short *)pcmBuffer length:(int)lengthOfShorts;

//解压缩
- (NSData*)decode:(Byte *)encodedBytes length:(int)lengthOfBytes;
- (void)close;

@end

