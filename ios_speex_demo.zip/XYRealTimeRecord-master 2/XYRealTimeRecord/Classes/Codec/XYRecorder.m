//
//  XYRecorder.m
//  XYRealTimeRecord
//
//  Created by zxy on 2017/3/17.
//  Copyright © 2017年 zxy. All rights reserved.
//

#import "XYRecorder.h"
#import "PCMDataPlayer.h"
#import "sys/utsname.h"

#define INPUT_BUS 1
#define OUTPUT_BUS 0

#define SAMPLE_RATE 8000


AudioUnit audioUnit;
AudioBufferList *buffList;
AVAudioSession *audioSession;
SpeexCodec *codec;
NSMutableData *resMuData;
NSMutableData *remainMuData;
PCMDataPlayer* player;

@implementation XYRecorder

#pragma mark - init

- (instancetype)init{
    self = [super init];
    if (self) {
        AudioUnitInitialize(audioUnit);
        [self initRemoteIO];
    }
    
    //自定义音频播放器的初始化
    if (player != nil) {
        [player stop];
        player = nil;
    }
    player = [[PCMDataPlayer alloc] init];
    
    return self;
}



- (void)initRemoteIO {
    [self setupAudioUnit];
    [self initAudioSession];
    //    [self initPlayCallback];
}


#pragma mark 录音的相关设置
-(void)setupAudioUnit{
    //initAudioComponent
    AudioComponentDescription audioDesc;
    audioDesc.componentType = kAudioUnitType_Output;
    //audioDesc.componentSubType = kAudioUnitSubType_RemoteIO;
    audioDesc.componentSubType = kAudioUnitSubType_VoiceProcessingIO;//回音消除
    audioDesc.componentFlags = 0;
    audioDesc.componentFlagsMask = 0;
    audioDesc.componentManufacturer = kAudioUnitManufacturer_Apple;
    AudioComponent inputComponent = AudioComponentFindNext(NULL, &audioDesc);
    AudioComponentInstanceNew(inputComponent, &audioUnit);
    
    //initAudioProperty
    UInt32 flag = 1;
    AudioUnitSetProperty(audioUnit,
                         kAudioOutputUnitProperty_EnableIO,
                         kAudioUnitScope_Input,
                         INPUT_BUS,
                         &flag,
                         sizeof(flag));
    UInt32 zero = 1;
    AudioUnitSetProperty(audioUnit,
                         kAudioOutputUnitProperty_EnableIO,
                         kAudioUnitScope_Output,
                         OUTPUT_BUS,
                         &zero,
                         sizeof(zero));
    
    //initFormat
    AudioStreamBasicDescription audioFormat;
    memset(&audioFormat, 0, sizeof(AudioStreamBasicDescription));
    audioFormat.mSampleRate = SAMPLE_RATE;//
    audioFormat.mFormatID = kAudioFormatLinearPCM;//
    audioFormat.mFormatFlags = kLinearPCMFormatFlagIsSignedInteger | kLinearPCMFormatFlagIsPacked;//
    audioFormat.mChannelsPerFrame = 1;//
    audioFormat.mFramesPerPacket = 1;
    audioFormat.mBitsPerChannel = 16;//
    audioFormat.mBytesPerFrame = 2;
    audioFormat.mBytesPerPacket = 2;
    AudioUnitSetProperty(audioUnit,
                         kAudioUnitProperty_StreamFormat,
                         kAudioUnitScope_Output,
                         INPUT_BUS,
                         &audioFormat,
                         sizeof(audioFormat));
    AudioUnitSetProperty(audioUnit,
                         kAudioUnitProperty_StreamFormat,
                         kAudioUnitScope_Input,
                         OUTPUT_BUS,
                         &audioFormat,
                         sizeof(audioFormat));
    
    
    //initRecordeCallback
    AURenderCallbackStruct recordCallback;
    recordCallback.inputProc = RecordCallback;
    recordCallback.inputProcRefCon = (__bridge void *)self;
    AudioUnitSetProperty(audioUnit,
                         kAudioOutputUnitProperty_SetInputCallback,
                         kAudioUnitScope_Global,
                         INPUT_BUS,
                         &recordCallback,
                         sizeof(recordCallback));
    
    UInt32 flag1 = 0;
    AudioUnitSetProperty(audioUnit,
                         kAudioUnitProperty_ShouldAllocateBuffer,
                         kAudioUnitScope_Output,
                         INPUT_BUS,
                         &flag1,
                         sizeof(flag1));
    
    AudioUnitInitialize(audioUnit);
}


- (void)initAudioSession {
    NSError *error;
    audioSession = [AVAudioSession sharedInstance];
    [audioSession setCategory:AVAudioSessionCategoryPlayAndRecord withOptions:AVAudioSessionCategoryOptionDefaultToSpeaker error:nil];
    [audioSession setPreferredSampleRate:SAMPLE_RATE error:&error];
  
    
    /*
     1.6系列及以下手机，与6s系列及以上手机，设置相同的回调间隔时间，输出的音频字节数不同。
     2.在recordCallback中，已经针对不同的音频字节数做了适配，全部凑成320字节压缩再传输。
     3.但是6系列及以下手机设置为0.1的回调间隔时间，在接收的音频中，每次avCheckAudioBuf(avIndex)，很多帧数据都会被丢弃，造成播放卡顿。而将6系列及以下手机设置为0.01，这个问题得到解决，同时因为0.1的回调字节数是2048，会连续发送6-7次，也是一个不太优的方式，固将两种类型的机型分开设计回调间隔时间。
     */
    if([self isLowerThan6]){
        [audioSession setPreferredIOBufferDuration:0.01 error:&error];
    }else{
        [audioSession setPreferredIOBufferDuration:0.1 error:&error];
    }
    
    [audioSession setMode:AVAudioSessionModeVoiceChat error:&error];//
    [audioSession setActive:YES error:nil];
}

//暂时不需要这个回调，这是录音的回放。
- (void)initPlayCallback {
    AURenderCallbackStruct playCallback;
    playCallback.inputProc = PlayCallback;
    playCallback.inputProcRefCon = (__bridge void *)self;
    AudioUnitSetProperty(audioUnit,
                         kAudioUnitProperty_SetRenderCallback,
                         kAudioUnitScope_Global,
                         OUTPUT_BUS,
                         &playCallback,
                         sizeof(playCallback));
}



#pragma mark 录音的回调函数
static OSStatus RecordCallback(void *inRefCon,
                               AudioUnitRenderActionFlags *ioActionFlags,
                               const AudioTimeStamp *inTimeStamp,
                               UInt32 inBusNumber,
                               UInt32 inNumberFrames,
                               AudioBufferList *ioData)
{
    AudioBuffer buffer;
    buffer.mNumberChannels = 1;
    buffer.mDataByteSize = inNumberFrames * 2;
    buffer.mData = malloc( inNumberFrames * 2 );
    AudioBufferList bufferList;
    bufferList.mNumberBuffers = 1;
    bufferList.mBuffers[0] = buffer;
    OSStatus result = AudioUnitRender(audioUnit,
                                      ioActionFlags,
                                      inTimeStamp,
                                      inBusNumber,
                                      inNumberFrames,
                                      &bufferList);
    short *data = (short *)bufferList.mBuffers[0].mData;
    int resDataBytesLenght = bufferList.mBuffers[0].mDataByteSize;
    
    if(resMuData == nil){
        resMuData = [NSMutableData dataWithCapacity:20];
        remainMuData = [NSMutableData dataWithCapacity:20];
    }
    [remainMuData appendBytes:data length:resDataBytesLenght];
    int num320 = (int)(remainMuData.length / 320);
    if(num320 == 0){
        return noErr;
    }
    
    for(int i =0;i<num320;i++){
        resMuData = [NSMutableData dataWithData:[remainMuData subdataWithRange:NSMakeRange(320*i, 320)]];
        
        //压缩
        const void *bytes1 =  [resMuData bytes];
        short input_frame[160];
        memcpy(input_frame, bytes1, 320);
        NSData *speexData = [codec encode:input_frame length:160];
        int encodeLength = (int)[speexData length];
        
        //解压缩
        const Byte *bytes = [speexData bytes];
        unsigned char charData[encodeLength];
        memcpy(charData,bytes,encodeLength);
        NSData *decodeData = [codec decode:charData length:encodeLength];
        
        //播放
        bytes1 =  [decodeData bytes];
        [player play:bytes1 length:320];
        
        [resMuData resetBytesInRange:NSMakeRange(0, [resMuData length])];
        [resMuData setLength:0];
    }
    remainMuData = [NSMutableData dataWithData:[remainMuData subdataWithRange:NSMakeRange(320*num320, remainMuData.length - 320*num320)]];
    
    //清空buffer mudata
    free(bufferList.mBuffers[0].mData);
    [resMuData resetBytesInRange:NSMakeRange(0, [resMuData length])];
    [resMuData setLength:0];
    if (result != noErr) {
        return result;
    }
    return noErr;
}


static OSStatus PlayCallback(void *inRefCon,
                             AudioUnitRenderActionFlags *ioActionFlags,
                             const AudioTimeStamp *inTimeStamp,
                             UInt32 inBusNumber,
                             UInt32 inNumberFrames,
                             AudioBufferList *ioData) {
    AudioUnitRender(audioUnit, ioActionFlags, inTimeStamp, 1, inNumberFrames, ioData);
    return noErr;
}

#pragma mark - public methods

- (void)startRecorder {
    //初始化
    codec = [[SpeexCodec alloc] init];
    [codec open:4];
    AudioOutputUnitStart(audioUnit);
    
}

- (void)stopRecorder {
    AudioOutputUnitStop(audioUnit);
    //关闭
    [codec close];
}


- (BOOL)isLowerThan6
{
    // 需要#import "sys/utsname.h"
    struct utsname systemInfo;
    uname(&systemInfo);
    NSString * deviceString = [NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding];
    NSComparisonResult result = [deviceString compare:@"iPhone8,1" options:NSCaseInsensitiveSearch];
    if(result == NSOrderedAscending){
        return true;
    }else{
        return false;
    }
    
    //iPhone
    //    if ([deviceString isEqualToString:@"iPhone1,1"])    return @"iPhone 1G";
    //    if ([deviceString isEqualToString:@"iPhone1,2"])    return @"iPhone 3G";
    //    if ([deviceString isEqualToString:@"iPhone2,1"])    return @"iPhone 3GS";
    //    if ([deviceString isEqualToString:@"iPhone3,1"])    return @"iPhone 4";
    //    if ([deviceString isEqualToString:@"iPhone3,2"])    return @"Verizon iPhone 4";
    //    if ([deviceString isEqualToString:@"iPhone4,1"])    return @"iPhone 4S";
    //    if ([deviceString isEqualToString:@"iPhone5,1"])    return @"iPhone 5";
    //    if ([deviceString isEqualToString:@"iPhone5,2"])    return @"iPhone 5";
    //    if ([deviceString isEqualToString:@"iPhone5,3"])    return @"iPhone 5C";
    //    if ([deviceString isEqualToString:@"iPhone5,4"])    return @"iPhone 5C";
    //    if ([deviceString isEqualToString:@"iPhone6,1"])    return @"iPhone 5S";
    //    if ([deviceString isEqualToString:@"iPhone6,2"])    return @"iPhone 5S";
    //    if ([deviceString isEqualToString:@"iPhone7,1"])    return @"iPhone 6 Plus";
    //    if ([deviceString isEqualToString:@"iPhone7,2"])    return @"iPhone 6";
    //    if ([deviceString isEqualToString:@"iPhone8,1"])    return @"iPhone 6s";
    //    if ([deviceString isEqualToString:@"iPhone8,2"])    return @"iPhone 6s Plus";
}



@end

